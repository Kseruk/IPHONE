# Jumpscare Edukacyjny
Strona edukacyjna ucząca, by nie klikać w podejrzane linki.